/** Who you play as. The flatmate brings her cat (entities/Cat.ts). */
export type HeroId = 'tenant' | 'flatmate';

export interface HeroInfo {
  readonly id: HeroId;
  readonly name: string;
  /** Pencilled under the name on the menu. */
  readonly note: string;
}

export const HEROES: readonly HeroInfo[] = [
  { id: 'tenant', name: 'the tenant', note: 'alone, and furious' },
  { id: 'flatmate', name: 'the flatmate', note: '+ biscuit, who wants tuna' },
];

export function isHeroId(value: unknown): value is HeroId {
  return value === 'tenant' || value === 'flatmate';
}
