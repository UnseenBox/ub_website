import { AdManager } from '../ads/AdManager';
import { MockAdProvider } from '../ads/MockAdProvider';
import { AnalyticsManager } from '../analytics/AnalyticsManager';
import { AudioManager } from '../audio/AudioManager';
import { Cat } from '../entities/Cat';
import { Enemy } from '../entities/Enemy';
import { ENEMY_TYPES, type EnemyTypeId } from '../entities/EnemyTypes';
import type { PhysicsObject } from '../entities/PhysicsObject';
import { Player } from '../entities/Player';
import { ChallengeSystem } from '../gameplay/ChallengeSystem';
import { extendChain, freshChain } from '../gameplay/Chain';
import { DiscoverySystem } from '../gameplay/DiscoverySystem';
import { ImpactSystem } from '../gameplay/ImpactSystem';
import { NavField } from '../gameplay/Navigation';
import { placePickups, updateRage } from '../gameplay/Pickups';
import type { RoomDefinition } from '../gameplay/Room';
import { dailyChallenge } from '../gameplay/RoomGenerator';
import { RoomManager, type RoomRuntime } from '../gameplay/RoomManager';
import { ScoreSystem } from '../gameplay/ScoreSystem';
import { Tutorial } from '../gameplay/Tutorial';
import { SOURCE_LEVEL } from '../hazards/Electricity';
import { ZoneManager } from '../hazards/Zone';
import { InputManager } from '../input/InputManager';
import { KeyboardMouseInput } from '../input/KeyboardMouseInput';
import { TouchInput } from '../input/TouchInput';
import { GADGET_RULES } from '../interactions/GadgetRules';
import { HOUSE_RULES } from '../interactions/HouseRules';
import { INTERACTION_RULES } from '../interactions/InteractionRegistry';
import { InteractionSystem } from '../interactions/InteractionSystem';
import { createObject } from '../objects/ObjectFactory';
import { ParticleSystem } from '../particles/ParticleSystem';
import { PhysicsWorld } from '../physics/PhysicsWorld';
import { Camera } from '../rendering/Camera';
import { Fx, impactWord } from '../rendering/Fx';
import { Renderer } from '../rendering/Renderer';
import { ReplayRecorder } from '../replay/ReplayRecorder';
import { SaveManager } from '../save/SaveManager';
import { FIXED_DT } from './constants';
import { EventBus } from './Events';
import { GameLoop } from './GameLoop';
import type { HeroId } from './Hero';
import { Rng } from './Random';
import type { Chain, Thing } from './types';

/** What a blast is made of: flames, scalding steam, or a firework going off. */
export type BlastStyle = 'fire' | 'steam' | 'sparkle';

export type GameState = 'menu' | 'playing' | 'paused' | 'cleared' | 'failed';

export interface RoomSummary {
  cleared: boolean;
  roomNumber: number;
  roomName: string;
  daily: boolean;
  score: number;
  highScore: number;
  isHighScore: boolean;
  bestChain: number;
  objectsUsed: number;
  newDiscoveries: number;
  challengeText: string | null;
  challengePassed: boolean;
  challengeBonus: number;
  canContinue: boolean;
}

/** What the simulation needs from the UI layer. Keeps Game free of DOM details. */
export interface GameUi {
  banner(title: string, sub?: string, seconds?: number): void;
  discovery(title: string): void;
  stateChanged(state: GameState): void;
  showSummary(summary: RoomSummary): void;
  /** Slams a rubber stamp across the screen ("CLEARED"). */
  stamp(text: string): void;
  frame(dt: number): void;
}

export interface Popup {
  text: string;
  x: number;
  y: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  tilt: number;
}

export interface Decal {
  kind: 'scorch' | 'scuff';
  x: number;
  y: number;
  r: number;
}

const OVERLAP_EVERY_TICKS = 10;
const CLEAR_DELAY = 1.6;
const FAIL_DELAY = 1.4;
const MAX_OBJECTS = 90;

const NULL_UI: GameUi = { banner() {}, discovery() {}, stateChanged() {}, showSummary() {}, stamp() {}, frame() {} };

export class Game {
  readonly bus = new EventBus();
  readonly rng = new Rng(1);
  readonly world = new PhysicsWorld();
  readonly zones = new ZoneManager();
  readonly particles = new ParticleSystem();
  readonly fx = new Fx();
  readonly audio = new AudioManager();
  readonly camera = new Camera();
  readonly save = new SaveManager();
  readonly analytics = new AnalyticsManager();
  readonly ads = new AdManager(new MockAdProvider());
  readonly replay = new ReplayRecorder();
  readonly nav = new NavField();
  readonly rooms = new RoomManager();
  readonly input: InputManager;
  readonly renderer: Renderer;
  readonly loop: GameLoop;
  readonly interactions: InteractionSystem;
  readonly impacts: ImpactSystem;
  readonly discoveries: DiscoverySystem;
  readonly score: ScoreSystem;
  readonly challenges: ChallengeSystem;
  readonly tutorial: Tutorial;

  hud: GameUi = NULL_UI;

  readonly objects: PhysicsObject[] = [];
  readonly enemies: Enemy[] = [];
  readonly popups: Popup[] = [];
  readonly decals: Decal[] = [];
  player: Player = new Player(0, 0);
  /** The flatmate's cat; null when playing as the tenant. */
  cat: Cat | null = null;
  room!: RoomRuntime;

  state: GameState = 'menu';
  /** Simulation time of the current room, in seconds. */
  time = 0;
  tickCount = 0;
  /** Real seconds left of the letterboxed final-blow slow motion. */
  cinema = 0;

  private scoreAtRoomStart = 0;
  private hitStopLeft = 0;
  private slowLeft = 0;
  private slowScale = 1;
  private revived = false;
  private consecutiveFailures = 0;

  constructor(readonly canvas: HTMLCanvasElement) {
    this.input = new InputManager(canvas);
    this.input.addSource(new KeyboardMouseInput());
    this.input.addSource(new TouchInput());
    this.renderer = new Renderer(this, canvas);
    this.interactions = new InteractionSystem(this, [...INTERACTION_RULES, ...HOUSE_RULES, ...GADGET_RULES]);
    this.impacts = new ImpactSystem(this);
    this.discoveries = new DiscoverySystem(this);
    this.score = new ScoreSystem(this);
    this.challenges = new ChallengeSystem(this);
    this.tutorial = new Tutorial(this);
    this.loop = new GameLoop({
      tick: (dt) => this.tick(dt),
      render: (alpha, frameDt) => this.frame(alpha, frameDt),
      timeScale: () => this.timeScale(),
    });

    this.world.pairFilter = (a, b) => {
      const oa = a.owner;
      const ob = b.owner;
      if (!oa || !ob || oa.kind !== 'object' || ob.kind !== 'object') return true;
      if (oa.restingOn === ob || ob.restingOn === oa) return false;
      if ((oa.fellFrom === ob && a.z > 2) || (ob.fellFrom === oa && b.z > 2)) return false;
      // Carried or airborne things pass over tables instead of bumping into their sides.
      const surface = oa.def.surface ? oa : ob.def.surface ? ob : null;
      if (surface) {
        const other = surface === oa ? ob : oa;
        if (!other.def.surface && (other.held || other.body.z > surface.def.height - 4)) return false;
      }
      return true;
    };

    this.wireFeedback();
    this.input.onAction((action) => {
      if (action === 'pause') this.togglePause();
      else if (action === 'restart' && (this.state === 'playing' || this.state === 'paused')) this.restartRoom();
    });
    this.ads.setHooks({
      onAdStart: () => this.audio.setDucked(true),
      onAdEnd: () => this.audio.setDucked(false),
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'playing') this.togglePause();
    });
  }

  start(): void {
    this.save.load();
    this.applySettings();
    void this.ads.initialize();
    // The first room doubles as the backdrop behind the main menu.
    this.loadRoom(this.rooms.definition(0), 0, false);
    this.setState('menu');
    this.analytics.track('game_start', { discoveries: this.discoveries.count });
    this.loop.start();
  }

  applySettings(): void {
    const settings = this.save.data.settings;
    this.audio.setVolume(settings.volume);
    this.audio.setMuted(settings.muted);
    this.audio.setMusicEnabled(settings.music);
    this.camera.shakeScale = settings.reducedShake ? 0.2 : 1;
    document.body.classList.toggle('high-contrast', settings.highContrast);
  }

  // ───────────── state & room flow ─────────────

  private setState(state: GameState): void {
    this.state = state;
    this.input.enabled = state === 'playing';
    this.input.flush();
    this.hud.stateChanged(state);
  }

  private loadRoom(def: RoomDefinition, index: number, daily: boolean): void {
    this.objects.length = 0;
    this.enemies.length = 0;
    this.popups.length = 0;
    this.decals.length = 0;
    this.zones.clear();
    this.particles.clear();
    this.fx.clear();
    this.cinema = 0;
    this.interactions.reset();
    this.time = 0;
    this.tickCount = 0;
    this.hitStopLeft = 0;
    this.slowLeft = 0;
    this.revived = false;
    this.rng.reseed(def.seed);
    this.player = new Player(def.playerStart.x, def.playerStart.y);
    this.room = this.rooms.build(this, def, index, daily);
    this.cat = this.hero === 'flatmate' ? new Cat(def.playerStart.x - 34, def.playerStart.y + 12) : null;
    placePickups(this);
    this.discoveries.newThisRoom = 0;
    this.score.resetRoom(this.scoreAtRoomStart);
    this.challenges.setForRoom(def.challenge);
    this.tutorial.begin(def.tutorial === true);
    this.replay.begin(def.id, def.seed);
  }

  get hero(): HeroId {
    return this.save.data.hero;
  }

  /** Picked on the menu; the room behind it is rebuilt so the cat turns up (or leaves). */
  setHero(hero: HeroId): void {
    if (hero === this.hero) return;
    this.save.data.hero = hero;
    this.save.write();
    if (this.state === 'menu') this.toMenu();
  }

  /** Starts a fresh run from the given room (0-based). */
  playFrom(index: number): void {
    this.scoreAtRoomStart = 0;
    this.consecutiveFailures = 0;
    this.enterRoom(this.rooms.definition(index), index, false);
  }

  playDaily(): void {
    this.scoreAtRoomStart = 0;
    this.consecutiveFailures = 0;
    this.enterRoom(dailyChallenge(new Date()).room, 0, true);
  }

  private enterRoom(def: RoomDefinition, index: number, daily: boolean): void {
    this.loadRoom(def, index, daily);
    this.setState('playing');
    this.bus.emit({ type: 'ROOM_START', room: index });
    this.analytics.track('room_start', { room: index + 1, daily, generated: index >= this.rooms.handcraftedCount });
  }

  restartRoom(): void {
    this.enterRoom(this.room.def, this.room.index, this.room.daily);
  }

  async retryAfterFail(): Promise<void> {
    await this.ads.onRetryAfterFailure();
    this.restartRoom();
  }

  async nextRoom(): Promise<void> {
    await this.ads.onRoomComplete();
    if (this.room.daily) {
      this.toMenu();
      return;
    }
    this.scoreAtRoomStart = this.score.score;
    const next = this.room.index + 1;
    this.enterRoom(this.rooms.definition(next), next, false);
  }

  /** Rewarded "second chance": back on your feet in the same room, as it stands. */
  async continueWithReward(): Promise<boolean> {
    if (this.state !== 'failed' || this.revived) return false;
    const granted = await this.ads.showRewarded('second_chance');
    if (!granted) return false;
    this.revived = true;
    this.player.revive();
    this.room.failTimer = 0;
    this.setState('playing');
    return true;
  }

  toMenu(): void {
    this.scoreAtRoomStart = 0;
    this.loadRoom(this.rooms.definition(0), 0, false);
    this.setState('menu');
  }

  togglePause(): void {
    if (this.state === 'playing') this.setState('paused');
    else if (this.state === 'paused') this.setState('playing');
  }

  get enemiesRemaining(): number {
    let alive = this.room.pending.length;
    for (const enemy of this.enemies) if (!enemy.defeated) alive++;
    return alive;
  }

  private summarize(cleared: boolean, challengeBonus: number): RoomSummary {
    const save = this.save.data;
    const isHighScore = this.score.score > save.highScore;
    if (isHighScore) save.highScore = this.score.score;
    if (cleared && !this.room.daily) {
      save.roomsCleared++;
      save.unlockedRoom = Math.max(save.unlockedRoom, this.room.index + 1);
    }
    this.save.write();
    const challenge = this.challenges.current;
    return {
      cleared,
      roomNumber: this.room.index + 1,
      roomName: this.room.def.name,
      daily: this.room.daily,
      score: this.score.score,
      highScore: save.highScore,
      isHighScore,
      bestChain: this.score.stats.bestChain,
      objectsUsed: this.score.stats.objectsUsed.size,
      newDiscoveries: this.discoveries.newThisRoom,
      challengeText: challenge ? challenge.text : null,
      challengePassed: challengeBonus > 0,
      challengeBonus,
      canContinue: !cleared && !this.revived && this.ads.isAvailable('rewarded'),
    };
  }

  private completeRoom(): void {
    const bonus = this.challenges.resolve();
    this.score.score += bonus;
    this.consecutiveFailures = 0;
    this.audio.play('roomClear', 1);
    this.bus.emit({ type: 'ROOM_COMPLETE', room: this.room.index });
    this.analytics.track('room_complete', {
      room: this.room.index + 1,
      score: this.score.score,
      seconds: Math.round(this.score.stats.time),
      bestChain: this.score.stats.bestChain,
    });
    const summary = this.summarize(true, bonus);
    this.setState('cleared');
    this.hud.showSummary(summary);
  }

  private failRoom(): void {
    this.consecutiveFailures++;
    this.audio.play('fail', 1);
    this.bus.emit({ type: 'ROOM_FAIL', room: this.room.index });
    this.analytics.track('room_fail', { room: this.room.index + 1, failures: this.consecutiveFailures });
    const summary = this.summarize(false, 0);
    this.setState('failed');
    this.hud.showSummary(summary);
  }

  // ───────────── simulation ─────────────

  private timeScale(): number {
    if (this.state !== 'playing' && this.state !== 'menu') return 0;
    if (this.hitStopLeft > 0) return 0.03;
    if (this.slowLeft > 0) return this.slowScale;
    return 1;
  }

  /** One fixed step. Public so tests and tools can advance the simulation deterministically. */
  tick(dt: number): void {
    const input = this.input.sample(this.camera.screenToWorld, this.player.body.x, this.player.body.y);
    if (this.state === 'menu') {
      // Keep the backdrop alive (settling objects, particles) without any gameplay.
      this.world.step(dt);
      this.cat?.update(this, dt);
      this.particles.update(dt);
      return;
    }
    if (this.state !== 'playing') return;

    this.time += dt;
    this.tickCount++;
    this.replay.record(input);

    const room = this.room;
    this.rooms.updateSpawns(this, room, dt);
    this.nav.update(this, dt);

    this.player.update(this, input, dt);
    if (!this.player.charging) this.audio.chargeStop();
    for (let i = 0; i < this.enemies.length; i++) this.enemies[i]!.update(this, dt);
    this.cat?.update(this, dt);
    updateRage(this, dt);
    for (let i = 0; i < this.objects.length; i++) {
      const object = this.objects[i]!;
      if (!object.alive) continue;
      object.update(this, dt);
      object.preStep();
    }

    this.world.step(dt);

    for (let i = 0; i < this.objects.length; i++) {
      const object = this.objects[i]!;
      if (object.alive) object.postStep();
    }
    this.impacts.process();

    this.zones.update(this, dt);
    if (this.tickCount % OVERLAP_EVERY_TICKS === 0) this.interactions.updateOverlaps(dt * OVERLAP_EVERY_TICKS);

    this.score.update(dt);
    this.tutorial.update(dt);
    this.particles.update(dt);
    this.sweep();
    this.updateRoomOutcome(dt);
  }

  private updateRoomOutcome(dt: number): void {
    const room = this.room;
    if (!this.player.alive) {
      room.failTimer += dt;
      if (room.failTimer >= FAIL_DELAY) this.failRoom();
      return;
    }
    if (!room.cleared && this.enemiesRemaining === 0) {
      room.cleared = true;
      room.clearTimer = 0;
      this.hud.stamp('CLEARED');
    }
    if (room.cleared) {
      room.clearTimer += dt;
      room.exitOpen = Math.min(1, room.exitOpen + dt * 2);
      if (room.clearTimer >= CLEAR_DELAY) this.completeRoom();
    }
  }

  private sweep(): void {
    let write = 0;
    for (let i = 0; i < this.objects.length; i++) {
      const object = this.objects[i]!;
      if (object.alive) this.objects[write++] = object;
      else this.world.remove(object.body);
    }
    this.objects.length = write;

    write = 0;
    for (let i = 0; i < this.enemies.length; i++) {
      const enemy = this.enemies[i]!;
      if (enemy.alive) this.enemies[write++] = enemy;
      else this.world.remove(enemy.body);
    }
    this.enemies.length = write;
  }

  /** Per display frame: real-time effects and drawing. */
  private frame(alpha: number, frameDt: number): void {
    if (this.hitStopLeft > 0) this.hitStopLeft -= frameDt;
    else if (this.slowLeft > 0) this.slowLeft -= frameDt;

    const pb = this.player.body;
    this.camera.follow(pb.prevX + (pb.x - pb.prevX) * alpha, pb.prevY + (pb.y - pb.prevY) * alpha, frameDt);
    this.camera.update(frameDt);
    this.fx.update(frameDt);
    if (this.cinema > 0) this.cinema -= frameDt;
    this.updateSoundscape(frameDt);
    if (this.state === 'playing') {
      let write = 0;
      for (let i = 0; i < this.popups.length; i++) {
        const p = this.popups[i]!;
        p.life -= frameDt;
        p.y -= 34 * frameDt;
        if (p.life > 0) this.popups[write++] = p;
      }
      this.popups.length = write;
    }
    this.renderer.render(alpha, frameDt);
    this.hud.frame(frameDt);
  }

  /** Hazard room tone and how many layers of the score are playing. */
  private updateSoundscape(dt: number): void {
    let fire = 0;
    let electric = 0;
    if (this.state === 'playing') {
      for (const zone of this.zones.zones) {
        if (!zone.alive) continue;
        if (zone.zone === 'fire') fire += zone.r > 20 ? 1 : 0.3;
        else if ((zone.zone === 'electric' && !zone.tags.has('outlet')) || zone.energized) electric += 0.6;
      }
    }
    this.audio.ambience(fire, electric, dt);

    let level = 0;
    if (this.state === 'paused') level = -1;
    else if (this.state === 'playing') {
      let alive = 0;
      for (const enemy of this.enemies) if (!enemy.defeated) alive++;
      const combo = this.score.combo;
      level = combo >= 4 || this.player.rage > 0 ? 3 : alive >= 3 || combo >= 2 ? 2 : alive >= 1 ? 1 : 0;
    }
    this.audio.setMusicIntensity(level);
  }

  // ───────────── services used by gameplay systems ─────────────

  spawnObject(id: string, x: number, y: number, angle = 0): PhysicsObject | null {
    if (this.objects.length >= MAX_OBJECTS) return null;
    const object = createObject(id, x, y, angle);
    if (!object) return null;
    this.objects.push(object);
    this.world.add(object.body);
    object.syncEmitters(this);
    return object;
  }

  spawnEnemy(type: EnemyTypeId, x: number, y: number, dirX = -1, dirY = 0): Enemy {
    const enemy = new Enemy(ENEMY_TYPES[type], x, y, dirX, dirY);
    this.enemies.push(enemy);
    this.world.add(enemy.body);
    if (enemy.type.electric) {
      this.zones.spawn(this, 'electric', x, y, enemy.type.radius + 9, {
        attached: enemy,
        level: SOURCE_LEVEL,
        extraTags: ['carried'],
      });
    }
    return enemy;
  }

  /** Radial blast: shoves everything, hurts creatures, breaks and ignites what it can. */
  explode(
    x: number,
    y: number,
    radius: number,
    damage: number,
    forceScale: number,
    chain: Chain | null,
    source: Thing | null,
    style: BlastStyle = 'fire',
  ): void {
    let hitEnemy = false;
    const victims: Array<{ thing: Thing; fall: number; dx: number; dy: number }> = [];
    this.world.queryCircle(x, y, radius, (body) => {
      const owner = body.owner;
      if (!owner || owner === source) return;
      const dx = body.x - x;
      const dy = body.y - y;
      const d = Math.hypot(dx, dy);
      if (d > radius + body.boundR) return;
      const fall = Math.max(0.15, 1 - d / radius);
      victims.push({ thing: owner, fall, dx: d > 0.01 ? dx / d : 1, dy: d > 0.01 ? dy / d : 0 });
    });

    // Collected first: reacting to a blast can spawn or remove bodies mid-query.
    for (const { thing, fall, dx, dy } of victims) {
      if (thing.kind === 'object') {
        if (!thing.alive) continue;
        const b = thing.body;
        b.applyImpulse(dx * 5200 * fall * forceScale, dy * 5200 * fall * forceScale);
        b.vz = Math.max(b.vz, 200 * fall);
        b.z = Math.max(b.z, 2);
        b.w += (Math.random() - 0.5) * 16 * fall;
        if (thing.restingOn) thing.leaveSurface();
        if (chain && !freshChain(thing, this.time)) {
          thing.chain = extendChain(chain, thing.label);
          thing.chainAt = this.time;
        }
        thing.tip(this, dx, dy);
        thing.applyDamage(this, 55 * fall * thing.material.fragility);
        if (style !== 'steam' && thing.alive && thing.def.flammable && fall > 0.45) {
          thing.igniteExposure += fall * 1.2 * thing.material.flammability;
          if (thing.igniteExposure >= 1) thing.ignite(this, chain);
        }
      } else if (thing.kind === 'enemy') {
        if (thing.defeated) continue;
        thing.stun = Math.max(thing.stun, 0.9 * thing.type.staggerFactor + 0.2);
        thing.squash = 1;
        thing.body.vx += dx * 560 * fall * thing.type.staggerFactor;
        thing.body.vy += dy * 560 * fall * thing.type.staggerFactor;
        thing.damage(this, damage * fall, { type: 'explosion', source, chain, label: 'EXPLOSION', dirX: dx, dirY: dy });
        if (chain) {
          thing.chain = extendChain(chain, thing.label);
          thing.chainAt = this.time;
        }
        hitEnemy = true;
      } else if (thing.kind === 'player') {
        if (thing.hurt(this, 1, 'EXPLOSION')) {
          thing.body.vx += dx * 420 * fall;
          thing.body.vy += dy * 420 * fall;
        }
      }
    }

    if (style === 'steam') {
      // a lid going through the ceiling: scalding, but nothing catches fire
      this.particles.burst('steam', x, y - 10, 34, 420);
      this.particles.burst('spark', x, y, 10, 500);
      this.fx.ring(x, y, 4, radius * 0.75, 0.6, 'rgba(228,247,251,0.9)', 4);
      this.fx.burst('PSSSHT!', x, y - 40, 1.6, '#e4f7fb', true);
      this.audio.play('explosion', 0.7);
      this.audio.play('hiss', 1);
    } else if (style === 'sparkle') {
      this.zones.spawn(this, 'fire', x, y, 22, { ttl: 2.2, chain: chain ? extendChain(chain, 'FIRE') : null });
      this.addDecal('scorch', x, y, radius * 0.3);
      this.particles.burst('confetti', x, y - 10, 46, 560);
      this.particles.burst('spark', x, y - 10, 40, 700);
      this.particles.burst('star', x, y - 10, 12, 380);
      this.fx.ring(x, y, 4, radius * 0.75, 0.6, 'rgba(255,90,138,0.9)', 4);
      this.fx.burst('BANG!', x, y - 40, 1.6, '#ff5a8a', true);
      this.audio.play('explosion', 0.6);
      this.audio.play('crackle', 1);
    } else {
      this.zones.spawn(this, 'fire', x, y, 34, { ttl: 4.5, chain: chain ? extendChain(chain, 'FIRE') : null });
      this.addDecal('scorch', x, y, radius * 0.55);
      this.particles.burst('ember', x, y, 40, 520);
      this.particles.burst('smoke', x, y, 18, 160);
      this.particles.burst('spark', x, y, 24, 600);
      this.fx.ring(x, y, 4, radius * 0.75, 0.6, 'rgba(255,159,28,0.9)', 4);
      this.fx.burst('KABOOM!', x, y - 40, 1.7, '#ff5a4e', true);
      this.audio.play('explosion', 1);
    }
    this.camera.addShake(0.9);
    this.camera.punchZoom(0.05);
    this.fx.flash('#ffffff', 0.6);
    this.fx.ring(x, y, 10, radius * 1.15, 0.45, 'rgba(255,255,255,0.95)', 7);
    this.hitStop(0.09);
    this.slowMotion(0.35, 0.45);
    this.noise(x, y, 1.5);
    this.bus.emit({ type: 'EXPLOSION', x, y, radius });
    if (hitEnemy) this.discoveries.unlock('kaboom');
  }

  /** Loud events draw intruders that have not noticed the player yet. */
  noise(x: number, y: number, loudness: number): void {
    const range = 520 * loudness;
    for (const enemy of this.enemies) {
      if (Math.hypot(enemy.body.x - x, enemy.body.y - y) < range) enemy.hearNoise(x, y);
    }
    this.bus.emit({ type: 'NOISE', x, y, loudness });
  }

  /** A decoy noise: movers in range head for it instead of for the player. */
  lure(x: number, y: number, radius: number, seconds: number): number {
    let count = 0;
    for (const enemy of this.enemies) {
      if (Math.hypot(enemy.body.x - x, enemy.body.y - y) < radius && enemy.lure(x, y, seconds)) count++;
    }
    return count;
  }

  popup(text: string, x: number, y: number, color = '#fff3d6', size = 20, seconds = 1.1): void {
    if (this.popups.length > 24) this.popups.shift();
    this.popups.push({ text, x, y, life: seconds, maxLife: seconds, color, size, tilt: (Math.random() - 0.5) * 0.22 });
  }

  addDecal(kind: Decal['kind'], x: number, y: number, r: number): void {
    if (this.decals.length > 30) this.decals.shift();
    this.decals.push({ kind, x, y, r });
  }

  slowMotion(scale: number, seconds: number): void {
    this.slowScale = scale;
    this.slowLeft = Math.max(this.slowLeft, seconds);
  }

  hitStop(seconds: number): void {
    this.hitStopLeft = Math.max(this.hitStopLeft, seconds);
  }

  // ───────────── juice: turn gameplay events into feedback ─────────────

  private wireFeedback(): void {
    const bus = this.bus;

    bus.on('OBJECT_BROKEN', (e) => {
      const object = e.object;
      const b = object.body;
      const brittle = object.material.sound === 'glass';
      const top = b.y - b.z - object.def.height * 0.5;
      this.particles.burst(object.material.debris, b.x, top, brittle ? 20 : 13, 290);
      this.particles.burst('dust', b.x, b.y, 5, 110);
      if (brittle) {
        this.audio.play('glassBreak', 0.9);
        this.fx.burst('SMASH!', b.x, top - 22, 1, '#d9fbf0');
      } else {
        this.audio.impact(object.material.sound, 1, b.mass);
        const sound = object.material.sound;
        this.fx.burst(sound === 'wood' ? 'CRACK!' : sound === 'soft' ? 'POOF!' : 'CRUNCH!', b.x, top - 22, 0.95);
      }
      this.fx.ring(b.x, b.y, 8, b.boundR + 44, 0.3, 'rgba(255,255,255,0.85)', 3);
      this.camera.addShake(0.24);
      this.noise(b.x, b.y, 0.8);
      this.analytics.track('object_break', { object: object.def.id });
    });

    bus.on('OBJECT_FALLEN', (e) => {
      const b = e.object.body;
      this.fx.burst(e.object.def.id === 'bookshelf' ? 'TIMBER!' : 'WHUMP!', b.x, b.y - 34, e.object.def.id === 'bookshelf' ? 1.3 : 0.95);
    });

    bus.on('ENEMY_HIT', (e) => {
      const enemy = e.enemy;
      const b = enemy.body;
      const cause = e.cause;
      const pitch = enemy.type.voice;
      const big = e.damage >= 20;

      if (cause.type === 'shock') {
        this.audio.voice('yelp', pitch);
        this.fx.burst('ZZAP!', b.x, b.y - 36, 1.05, '#fff27a');
      } else if (cause.type === 'fire') {
        this.audio.voice('panic', pitch);
      } else {
        this.audio.voice('oof', pitch);
        if (big) {
          const source = cause.source;
          const quirk = source && source.kind === 'object' ? source.def.quirk : undefined;
          const word =
            quirk === 'gong'
              ? 'DONG!'
              : quirk === 'squeak'
                ? 'SQUEAK!'
                : cause.type === 'impact' && source && source.kind === 'object'
              ? impactWord(source.material.sound)
              : cause.type === 'slam'
                ? 'WHAM!'
                : cause.type === 'glass'
                  ? 'OUCH!'
                  : cause.type === 'explosion'
                    ? ''
                    : 'BONK!';
          if (word) this.fx.burst(word, b.x - cause.dirX * 8, b.y - 34, 0.75 + Math.min(0.6, e.damage / 70));
        }
      }

      const directional = cause.dirX !== 0 || cause.dirY !== 0;
      this.particles.burst(
        'star',
        b.x,
        b.y - 12,
        Math.min(9, 2 + Math.floor(e.damage / 9)),
        220,
        directional ? { dirX: cause.dirX, dirY: cause.dirY, spread: 0.75 } : undefined,
      );
      if (big) this.fx.ring(b.x, b.y, 6, 30 + e.damage * 0.5, 0.26, 'rgba(255,255,255,0.85)', 3);
      this.camera.addShake(Math.min(0.4, e.damage / 140));
      if (directional) this.camera.kick(cause.dirX * Math.min(7, e.damage / 7), cause.dirY * Math.min(7, e.damage / 7));
      if (e.damage >= 50) this.hitStop(0.09);
      else if (e.damage >= 28) this.hitStop(0.055);
    });

    bus.on('ENEMY_DEFEATED', (e) => {
      const b = e.enemy.body;
      this.audio.voice('defeat', e.enemy.type.voice);
      // the box bursts: packing peanuts everywhere
      this.particles.burst('peanut', b.x, b.y - 14, 22, 300);
      this.fx.ring(b.x, b.y, 10, 70, 0.4, 'rgba(255,255,255,0.9)', 4);
      if (this.enemiesRemaining === 0) {
        // The last one out gets the full treatment: letterbox, slow motion, a push-in.
        this.cinema = 1.25;
        this.slowMotion(0.18, 1.15);
        this.camera.focus(b.x, b.y, 1.25, 1.2);
        this.camera.addShake(0.45);
        this.fx.burst('K.O.!', b.x, b.y - 48, 1.5, '#ff5a4e', true);
        this.fx.flash('#ffffff', 0.3);
        this.particles.burst('confetti', b.x, b.y - 14, 26, 420);
        this.hitStop(0.12);
      } else {
        this.camera.addShake(0.3);
        this.camera.punchZoom(0.025);
        this.hitStop(0.09);
      }
      this.analytics.track('enemy_defeat', {
        enemy: e.enemy.type.id,
        cause: e.cause.type,
        with: e.cause.label,
        chain: e.cause.chain ? e.cause.chain.steps.length : 0,
      });
    });

    bus.on('PLAYER_DEFEATED', () => {
      this.slowMotion(0.25, 1.2);
      this.particles.burst('star', this.player.body.x, this.player.body.y, 16, 240);
    });

    bus.on('OBJECT_GRABBED', (e) => this.analytics.track('object_grab', { object: e.object.def.id }));
    bus.on('OBJECT_THROWN', (e) => this.analytics.track('object_throw', { object: e.object.def.id, charge: Math.round(e.charge * 100) }));
    bus.on('DISCOVERY', (e) => {
      // like a camera flash going off: this one is going on the evidence board
      if (e.isNew) this.fx.flash('#ffffff', 0.2);
      this.analytics.track('new_discovery', { id: e.id, total: this.discoveries.count });
    });
    bus.on('CHAIN', (e) => {
      this.camera.addShake(0.25);
      this.analytics.track('chain_reaction', { length: e.length, steps: e.steps.join('>') });
    });
    bus.onAny((event) => this.replay.observe(event));
  }

  /** Advances the simulation by a number of fixed steps without waiting for frames (tests, tools). */
  stepManually(ticks: number): void {
    for (let i = 0; i < ticks; i++) this.tick(FIXED_DT);
  }
}
