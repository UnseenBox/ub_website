import type { AudioManager } from './AudioManager';
import { VOWEL } from './Synth';

/**
 * The cat's voice and the hero losing their temper. Built from the same formant voice as
 * everyone else, only much higher: a meow is an "ee-ah-oo" glide, a hiss is filtered noise.
 */

const CAT = 620;

export function meow(audio: AudioManager, mood: 'hello' | 'scared' | 'war' = 'hello'): void {
  const s = audio.synth(`cat:${mood}`, 0.3);
  if (!s) return;
  const b = CAT * (0.94 + Math.random() * 0.12);
  if (mood === 'hello') {
    s.voice({ pitch: [b * 0.9, b * 1.25, b * 0.85], dur: 0.34, from: VOWEL.i, to: VOWEL.a, gain: 0.13 });
  } else if (mood === 'scared') {
    // a yowl that climbs and wobbles
    s.voice({ pitch: [b * 0.8, b * 1.5, b * 1.7], dur: 0.42, from: VOWEL.e, to: VOWEL.i, gain: 0.15, vibrato: { rate: 22, depth: b * 0.12 } });
  } else {
    // the long low one cats make before a fight
    s.voice({ pitch: [b * 0.55, b * 0.7, b * 1.3, b * 0.6], dur: 0.7, from: VOWEL.a, to: VOWEL.o, gain: 0.2, vibrato: { rate: 14, depth: b * 0.08 } });
  }
}

export function hiss(audio: AudioManager): void {
  const s = audio.synth('cat:hiss', 0.25);
  if (!s) return;
  s.noise({ filter: 'highpass', from: 3600, to: 5200, dur: 0.32, gain: 0.2, attack: 0.03 });
  s.noise({ filter: 'bandpass', from: 2400, dur: 0.05, gain: 0.14, q: 2 });
}

export function scratch(audio: AudioManager): void {
  const s = audio.synth('cat:scratch', 0.07);
  if (!s) return;
  const f = 1800 + Math.random() * 1400;
  s.noise({ filter: 'bandpass', from: f, to: f * 2.2, dur: 0.05, gain: 0.2, q: 3 });
  s.noise({ filter: 'bandpass', from: f * 1.3, to: f * 2.6, dur: 0.05, gain: 0.16, q: 3, delay: 0.035 });
}

export function purr(audio: AudioManager): void {
  const s = audio.synth('cat:purr', 1.5);
  if (!s) return;
  for (let i = 0; i < 7; i++) s.tone({ type: 'triangle', from: 52, to: 46, dur: 0.07, gain: 0.12, delay: i * 0.085 });
}

/** Tin lid peeling back. */
export function tinOpen(audio: AudioManager): void {
  const s = audio.synth('tin', 0.2);
  if (!s) return;
  s.noise({ filter: 'bandpass', from: 900, to: 3800, dur: 0.16, gain: 0.2, q: 4 });
  s.tone({ type: 'triangle', from: 1900, to: 2500, dur: 0.07, gain: 0.1, delay: 0.15 });
}

/** Biting into the pepper, a beat of silence, then the scream. */
export function rageStart(audio: AudioManager): void {
  const s = audio.synth('rage:start', 0.5);
  if (!s) return;
  s.noise({ filter: 'bandpass', from: 1500, to: 600, dur: 0.05, gain: 0.25, q: 2 });
  s.voice({ pitch: [210, 330, 520, 480], dur: 0.75, from: VOWEL.a, to: VOWEL.a, gain: 0.3, delay: 0.22, vibrato: { rate: 26, depth: 34 } });
  s.noise({ filter: 'highpass', from: 2200, to: 5200, dur: 0.6, gain: 0.1, attack: 0.1, delay: 0.3 });
}

export function rageShout(audio: AudioManager): void {
  const s = audio.synth('rage:shout', 0.6);
  if (!s) return;
  const b = 260 + Math.random() * 60;
  s.voice({ pitch: [b, b * 1.5, b * 1.2], dur: 0.3, from: VOWEL.a, to: VOWEL.e, gain: 0.24, vibrato: { rate: 28, depth: 26 } });
}

/** The kettle coming off the boil. */
export function rageEnd(audio: AudioManager): void {
  const s = audio.synth('rage:end', 0.5);
  if (!s) return;
  s.noise({ filter: 'highpass', from: 4200, to: 1500, dur: 0.7, gain: 0.14, attack: 0.02 });
  s.voice({ pitch: [300, 170], dur: 0.45, from: VOWEL.o, to: VOWEL.u, gain: 0.2, delay: 0.15 });
}
