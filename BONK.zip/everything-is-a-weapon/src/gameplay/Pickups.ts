import { rageEnd, rageShout, rageStart, tinOpen } from '../audio/CompanionSounds';
import type { Game } from '../core/Game';
import type { Enemy } from '../entities/Enemy';
import type { PhysicsObject } from '../entities/PhysicsObject';
import { doorPosition } from './Room';

/** How long a ghost pepper lasts. */
export const RAGE_SECONDS = 60;
/** What rage does to the hero's numbers (read by entities/Player.ts). */
export const RAGE_SPEED = 1.3;
export const RAGE_THROW = 1.3;
export const RAGE_CHARGE = 2.4;

const RAM_DAMAGE = 9;
const RAM_EVERY = 0.6;
const SHOUTS = ['GET OUT!', 'MY FLAT!', 'RAAAGH!', 'I PAY RENT HERE!', 'NOT THE SOFA!', 'IT IS 3 A.M.!', 'OUT! OUT! OUT!'] as const;

const rammed = new WeakMap<Enemy, number>();
let steamTimer = 0;
let shoutTimer = 0;

/**
 * Called when the hero's hand closes on something. Returns true if it was used up there
 * and then instead of being picked up.
 */
export function consumePickup(game: Game, object: PhysicsObject): boolean {
  const kind = object.def.consume;
  const b = object.body;
  if (kind === 'rage') {
    const player = game.player;
    object.alive = false;
    player.rage = RAGE_SECONDS;
    steamTimer = 0;
    shoutTimer = 2.5;
    rageStart(game.audio);
    game.fx.burst('RAAAGH!', player.body.x, player.body.y - 62, 1.5, '#ff5a4e', true);
    game.fx.flash('#ff3b2f', 0.45);
    game.fx.ring(player.body.x, player.body.y, 10, 150, 0.5, 'rgba(255,90,78,0.95)', 6);
    game.particles.burst('ember', player.body.x, player.body.y - 30, 26, 380);
    game.particles.burst('steam', player.body.x, player.body.y - 44, 12, 200);
    game.camera.addShake(0.7);
    game.camera.punchZoom(0.05);
    game.hitStop(0.12);
    game.hud.banner('SEEING RED', 'one minute of blind rage', 2.2);
    game.discoveries.unlock('hot_head');
    game.analytics.track('object_grab', { object: object.def.id });
    return true;
  }
  if (kind === 'tuna' && game.cat) {
    object.alive = false;
    tinOpen(game.audio);
    game.particles.burst('water', b.x, b.y - 8, 8, 160);
    game.popup('pssht', b.x, b.y - 22, '#fff3d6', 14, 0.7);
    game.cat.feed(game);
    game.camera.addShake(0.3);
    game.hud.banner('DINNER TIME', 'the cat is not hiding any more', 2);
    game.analytics.track('object_grab', { object: object.def.id });
    return true;
  }
  return false;
}

/** A clear bit of floor, away from the hero's feet and the door the movers come through. */
function freeSpot(game: Game, out: { x: number; y: number }): boolean {
  const def = game.room.def;
  const door = doorPosition(def, def.entrance, 24);
  for (let attempt = 0; attempt < 60; attempt++) {
    const x = game.rng.range(60, def.width - 60);
    const y = game.rng.range(70, def.height - 50);
    if (Math.hypot(x - def.playerStart.x, y - def.playerStart.y) < 130) continue;
    if (Math.hypot(x - door.x, y - door.y) < 150) continue;
    let clear = true;
    game.world.queryCircle(x, y, 26, () => (clear = false));
    if (!clear) continue;
    out.x = x;
    out.y = y;
    return true;
  }
  return false;
}

/**
 * Drops this room's pickups. Uses the room's own seeded RNG, so a retry finds them in the
 * same places. The first room is left alone: it is the tutorial and the menu backdrop.
 */
export function placePickups(game: Game): void {
  const room = game.room;
  if (room.def.tutorial || (room.index === 0 && !room.daily)) return;
  const spot = { x: 0, y: 0 };
  // Always in the second room, so everyone meets it once; a coin toss after that.
  const pepper = room.index === 1 || game.rng.next() < 0.5;
  if (pepper && freeSpot(game, spot)) game.spawnObject('chili', spot.x, spot.y, game.rng.range(0, Math.PI * 2));
  if (game.cat) {
    const tins = room.index >= 6 || room.daily ? 2 : 1;
    for (let i = 0; i < tins; i++) {
      if (freeSpot(game, spot)) game.spawnObject('tuna', spot.x, spot.y);
    }
  }
}

/** Per fixed step while the hero is alive: steam, shouting, shoulder-barging, and the comedown. */
export function updateRage(game: Game, dt: number): void {
  const player = game.player;
  if (player.rage <= 0) return;
  const pb = player.body;
  if (!player.alive) {
    player.rage = 0;
    return;
  }
  player.rage -= dt;
  if (player.rage <= 0) {
    player.rage = 0;
    rageEnd(game.audio);
    game.particles.burst('steam', pb.x, pb.y - 40, 16, 150);
    game.popup('...phew', pb.x, pb.y - 62, '#fff3d6', 16, 1.4);
    return;
  }

  // steam out of both ears
  steamTimer -= dt;
  if (steamTimer <= 0) {
    steamTimer = 0.09;
    for (const side of [-1, 1]) {
      game.particles.burst('steam', pb.x + side * 13, pb.y - 40, 1, 70, { dirX: side, dirY: -0.5, spread: 0.5 });
    }
  }

  shoutTimer -= dt;
  if (shoutTimer <= 0) {
    shoutTimer = 3.2 + Math.random() * 3;
    rageShout(game.audio);
    game.popup(SHOUTS[Math.floor(Math.random() * SHOUTS.length)]!, pb.x, pb.y - 66, '#ff8b7a', 18, 1.1);
  }

  // Walking into a mover is an attack now.
  const speed = pb.speed();
  if (speed < 90) return;
  for (const enemy of game.enemies) {
    if (enemy.defeated) continue;
    const dx = enemy.body.x - pb.x;
    const dy = enemy.body.y - pb.y;
    const d = Math.hypot(dx, dy) || 1;
    if (d > enemy.type.radius + pb.boundR + 7) continue;
    if (game.time - (rammed.get(enemy) ?? -9) < RAM_EVERY) continue;
    rammed.set(enemy, game.time);
    enemy.stun = Math.max(enemy.stun, 0.5 * enemy.type.staggerFactor);
    enemy.squash = 1;
    enemy.body.vx += (dx / d) * 420 * enemy.type.staggerFactor;
    enemy.body.vy += (dy / d) * 420 * enemy.type.staggerFactor;
    game.audio.impact('soft', 0.9, 30);
    game.fx.burst('RAM!', enemy.body.x, enemy.body.y - 40, 0.85, '#ff5a4e', true);
    enemy.damage(game, RAM_DAMAGE, { type: 'impact', source: player, chain: null, label: 'SHOULDER', dirX: dx / d, dirY: dy / d });
    if (enemy.defeated) game.discoveries.unlock('road_rage');
  }
}
