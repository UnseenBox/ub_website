import { INK } from '../core/constants';
import { TAU } from '../core/math';
import { onTop, prism, type Ctx } from './draw';
import { registerObjectArt, type ArtContext } from './ObjectArt';

/**
 * Drawings for the pickups (objects/PickupObjects.ts). They hover and glow a little so they
 * read as "take me" rather than "throw me".
 */

type Art = (a: ArtContext) => void;

/** A slow pulse on the floor underneath, and how far the thing is bobbing above it. */
function beacon(ctx: Ctx, x: number, y: number, time: number, color: string, seed: number): number {
  const pulse = 0.5 + 0.5 * Math.sin(time * 3.2 + seed);
  ctx.globalAlpha = 0.2 + pulse * 0.25;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.ellipse(x, y + 1, 13 + pulse * 5, (13 + pulse * 5) * 0.62, 0, 0, TAU);
  ctx.stroke();
  ctx.globalAlpha = 1;
  return 3 + Math.sin(time * 2.6 + seed) * 2;
}

function twinkle(ctx: Ctx, x: number, y: number, time: number, seed: number): void {
  const t = (time * 0.9 + seed) % 1;
  const a = seed * 2.4 + Math.floor(time * 0.9 + seed) * 2.1;
  const sx = x + Math.cos(a) * 12;
  const sy = y + Math.sin(a) * 8;
  const r = Math.sin(t * Math.PI) * 3.6;
  if (r < 0.4) return;
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(sx - r, sy);
  ctx.lineTo(sx + r, sy);
  ctx.moveTo(sx, sy - r);
  ctx.lineTo(sx, sy + r);
  ctx.stroke();
  ctx.lineCap = 'butt';
}

const chili: Art = ({ ctx, o, x, y, z, angle, time, tone }) => {
  const lift = o.held || z > 1 ? 0 : beacon(ctx, x, y, time, '#ff5a4e', o.seed);
  onTop(ctx, x, y, angle, z + 3 + lift, (c) => {
    // the pod: a fat comma
    const pod = (): void => {
      c.beginPath();
      c.moveTo(-8, -3.5);
      c.quadraticCurveTo(1, -8, 8, -1);
      c.quadraticCurveTo(11, 3.5, 9.5, 5);
      c.quadraticCurveTo(3, 1.5, -6.5, 3.5);
      c.quadraticCurveTo(-10.5, 1, -8, -3.5);
      c.closePath();
    };
    c.lineJoin = 'round';
    pod();
    c.strokeStyle = INK;
    c.lineWidth = 3.4;
    c.stroke();
    c.fillStyle = tone('#e5383b');
    c.fill();
    c.strokeStyle = tone('#ff9a8a');
    c.lineWidth = 1.6;
    c.lineCap = 'round';
    c.beginPath();
    c.moveTo(-4.5, -3);
    c.quadraticCurveTo(1, -5, 5, -1.6);
    c.stroke();
    // stalk
    c.strokeStyle = INK;
    c.lineWidth = 5;
    c.beginPath();
    c.moveTo(-8, -1);
    c.quadraticCurveTo(-12, -2, -12.5, -6);
    c.stroke();
    c.strokeStyle = tone('#4caf50');
    c.lineWidth = 2.4;
    c.stroke();
    c.lineCap = 'butt';
  });
  // it is so hot the air above it wobbles
  const top = y - z - lift - 12;
  ctx.strokeStyle = 'rgba(255, 190, 120, 0.75)';
  ctx.lineWidth = 1.6;
  ctx.lineCap = 'round';
  for (let i = -1; i <= 1; i++) {
    const t = (time * 1.4 + o.seed + i * 0.33) % 1;
    ctx.globalAlpha = Math.sin(t * Math.PI) * 0.8;
    const wx = x + i * 5 + Math.sin(time * 6 + i) * 1.5;
    ctx.beginPath();
    ctx.moveTo(wx, top - t * 10);
    ctx.quadraticCurveTo(wx + 2.5, top - t * 10 - 3, wx, top - t * 10 - 6);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.lineCap = 'butt';
};

const tuna: Art = ({ ctx, o, x, y, z, angle, time, tone }) => {
  const lift = o.held || z > 1 ? 0 : beacon(ctx, x, y, time, '#7fd6ff', o.seed);
  const base = z + lift;
  prism(ctx, x, y, angle, base, base + 5, (c) => c.arc(0, 0, 8, 0, TAU), tone('#3f7cac'), tone('#c9d2e0'), INK, 3.2);
  onTop(ctx, x, y, 0, base + 5, (c) => {
    c.strokeStyle = 'rgba(34, 27, 54, 0.35)';
    c.lineWidth = 1;
    c.beginPath();
    c.arc(0, 0, 5.6, 0, TAU);
    c.stroke();
    // a little fish stamped on the lid
    c.fillStyle = tone('#3f7cac');
    c.beginPath();
    c.ellipse(-0.8, 0, 3.6, 2.1, 0, 0, TAU);
    c.moveTo(2.2, 0);
    c.lineTo(5, -2.2);
    c.lineTo(5, 2.2);
    c.closePath();
    c.fill();
    c.fillStyle = '#ffffff';
    c.beginPath();
    c.arc(-2.4, -0.5, 0.7, 0, TAU);
    c.fill();
  });
  if (lift > 0) twinkle(ctx, x, y - base - 5, time, o.seed);
};

export function registerPickupArt(): void {
  registerObjectArt('chili', chili);
  registerObjectArt('tuna', tuna);
}
