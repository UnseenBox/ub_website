import './styles.css';
import { Game } from './core/Game';
import { UI } from './ui/UI';

function required<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing #${id} in index.html`);
  return node as T;
}

function boot(): void {
  const canvas = required<HTMLCanvasElement>('game');
  const game = new Game(canvas);
  game.hud = new UI(game, required('hud'), required('screens'));

  // Browsers only allow audio after a gesture; the first click or key press unlocks it.
  const unlock = (): void => game.audio.unlock();
  window.addEventListener('pointerdown', unlock);
  window.addEventListener('keydown', unlock);

  required('rotate-dismiss').addEventListener('click', () => document.body.classList.add('portrait-ok'));

  game.start();

  if (import.meta.env.DEV) {
    // Development-only tooling; this branch is removed from production builds.
    void import('./debug/DebugOverlay').then(({ DebugOverlay }) => new DebugOverlay(game, required('debug')));
    void import('./debug/TestHooks').then(({ installTestHooks }) => installTestHooks(game));
    (window as unknown as { __game: Game }).__game = game;
  }
}

try {
  boot();
} catch (error) {
  console.error(error);
  const message = document.createElement('div');
  message.className = 'fatal';
  message.textContent = 'This browser could not start the game. Try a current version of Chrome, Edge, Firefox or Safari.';
  document.body.append(message);
}
