import type { RoomSummary } from '../core/Game';
import { button, el, formatScore } from './dom';

export interface ResultsActions {
  next(): void;
  retry(): void;
  continueWithReward(): void;
  home(): void;
  /** Called at the moment the rubber stamp hits the page. */
  stamped(): void;
}

function field(labelText: string, value: string): { row: HTMLElement; value: HTMLElement } {
  const row = el('div', 'field');
  const valueNode = el('span', 'field-value', value);
  row.append(el('span', 'field-label', labelText), el('span', 'field-dots'), valueNode);
  return { row, value: valueNode };
}

/** Counts a number up over about a second, like someone totting up a bill. */
function countUp(node: HTMLElement, target: number): void {
  const start = performance.now();
  const duration = 900;
  const step = (now: number): void => {
    if (!node.isConnected) return;
    const t = Math.min(1, (now - start) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    node.textContent = formatScore(target * eased);
    if (t < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
  // If frames are throttled the final value must still land.
  window.setTimeout(() => {
    if (node.isConnected) node.textContent = formatScore(target);
  }, duration + 200);
}

/** The end-of-room screen: an incident report on a clipboard, finished off with a rubber stamp. */
export function buildResults(summary: RoomSummary, actions: ResultsActions): HTMLElement {
  const screen = el('div', `screen results ${summary.cleared ? 'cleared' : 'failed'}`);
  const clipboard = el('div', 'clipboard');
  const sheet = el('div', 'sheet');

  const head = el('div', 'sheet-head');
  head.append(
    el('span', 'sheet-title', 'INCIDENT REPORT'),
    el('span', 'sheet-no', summary.daily ? 'DAILY' : `No. ${String(summary.roomNumber).padStart(3, '0')}`),
  );
  const where = el('div', 'sheet-where');
  where.append(
    el('span', 'field-label', 'LOCATION'),
    el('span', 'handwritten', `${summary.daily ? 'daily challenge' : `room ${summary.roomNumber}`} — ${summary.roomName.toLowerCase()}`),
  );

  const fields = el('div', 'fields');
  const score = field('DAMAGE BILL', '0');
  fields.append(
    score.row,
    field('LONGEST CHAIN', summary.bestChain > 0 ? `x${summary.bestChain}` : '—').row,
    field('OBJECTS MISUSED', String(summary.objectsUsed)).row,
    field('NEW EVIDENCE', String(summary.newDiscoveries)).row,
  );
  countUp(score.value, summary.score);

  sheet.append(head, where, fields);

  if (summary.challengeText && summary.cleared) {
    const bonus = el('div', `bonus-line ${summary.challengePassed ? 'passed' : 'missed'}`);
    bonus.append(
      el('span', 'bonus-box'),
      el('span', 'bonus-text', summary.challengeText.toLowerCase()),
      el('span', 'bonus-points', summary.challengePassed ? `+${formatScore(summary.challengeBonus)}` : ''),
    );
    sheet.append(bonus);
  }

  const stamp = el('div', 'stamp-mark', summary.cleared ? 'CLEARED' : 'EVICTED');
  sheet.append(stamp);
  window.setTimeout(() => {
    if (!stamp.isConnected) return;
    stamp.classList.add('show');
    actions.stamped();
  }, 420);

  if (summary.isHighScore && summary.score > 0) sheet.append(el('div', 'best-sticker', 'NEW BEST'));

  clipboard.append(el('div', 'clip'), sheet);
  screen.append(clipboard);

  const buttons = el('div', 'menu-buttons row');
  if (summary.cleared) {
    buttons.append(button(summary.daily ? 'DONE' : 'NEXT ROOM', 'primary', actions.next), button('REPLAY', '', actions.retry));
  } else {
    buttons.append(button('RETRY', 'primary', actions.retry));
    // Only offered when a rewarded ad is genuinely available; never forced.
    if (summary.canContinue) buttons.append(button('CONTINUE', '', actions.continueWithReward));
  }
  buttons.append(button('HOME', '', actions.home));
  screen.append(buttons);
  return screen;
}
