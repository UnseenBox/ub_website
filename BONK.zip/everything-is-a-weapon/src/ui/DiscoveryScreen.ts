import type { Game } from '../core/Game';
import { DISCOVERIES, type DiscoveryDefinition } from '../gameplay/Discoveries';
import { button, el, ransom } from './dom';

const GROUP_TITLES: Readonly<Record<DiscoveryDefinition['group'], string>> = {
  impact: 'blunt instruments',
  electric: 'electricity',
  fire: 'fire',
  floor: 'the floor',
  air: 'air & pressure',
  gadget: 'contraptions',
  style: 'style',
};

const PIN_COLORS = ['#e5383b', '#2f4fb5', '#ffd23f', '#3fa7a3', '#fbf6e9'];

function card(definition: DiscoveryDefinition, found: boolean, index: number): HTMLElement {
  const node = el('div', `evidence ${found ? 'found' : 'unknown'}`);
  node.style.setProperty('--tilt', `${[-2.2, 1.4, -0.8, 2.4, -1.6, 0.9][index % 6]}deg`);
  const pin = el('span', 'pin');
  pin.style.setProperty('--pin', PIN_COLORS[index % PIN_COLORS.length]!);
  node.append(pin);

  if (!found) {
    // Not found yet: a face-down file. The redaction bars give away only how many steps it has.
    node.append(el('div', 'evidence-title', '?'));
    const bars = el('div', 'redacted');
    definition.recipe.forEach((_, i) => {
      if (i > 0) bars.append(el('span', 'string'));
      bars.append(el('span', 'bar'));
    });
    node.append(bars);
    return node;
  }

  node.append(el('div', 'evidence-title', definition.title));
  const recipe = el('div', 'recipe');
  definition.recipe.forEach((step, i) => {
    if (i > 0) recipe.append(el('span', 'string'));
    recipe.append(el('span', 'step', step.toLowerCase()));
  });
  node.append(recipe);
  return node;
}

/**
 * The collection, as a detective's corkboard: index cards pinned up, steps joined with red
 * string. Unfound interactions are face-down files.
 */
export function buildDiscoveryScreen(game: Game, onBack: () => void): HTMLElement {
  const screen = el('div', 'screen discoveries');
  const header = el('div', 'board-head');
  header.append(
    ransom('EVIDENCE', 21, 'board-title'),
    el('div', 'tape-label', `${game.discoveries.count} of ${game.discoveries.total} ways found`),
  );
  screen.append(header);

  const board = el('div', 'board');
  let index = 0;
  for (const group of Object.keys(GROUP_TITLES) as Array<DiscoveryDefinition['group']>) {
    const entries = DISCOVERIES.filter((d) => d.group === group);
    const found = entries.filter((d) => game.discoveries.has(d.id)).length;
    board.append(el('h3', 'tape-label group', `${GROUP_TITLES[group]}  ${found}/${entries.length}`));
    const grid = el('div', 'evidence-grid');
    for (const definition of entries) grid.append(card(definition, game.discoveries.has(definition.id), index++));
    board.append(grid);
  }
  screen.append(board, button('BACK', 'primary', onBack));
  return screen;
}
