import type { Game } from '../core/Game';
import { button, el, ransom } from './dom';

const PIN_COLORS = ['#e5383b', '#2f4fb5', '#ffd23f', '#3fa7a3', '#fbf6e9'];

/**
 * Every room you have reached, as a rack of numbered key tags. Any of them can be started
 * again; the furthest one is flagged so it is easy to carry on where you left off.
 */
export function buildRoomPicker(game: Game, onPick: (roomIndex: number) => void, onBack: () => void): HTMLElement {
  const unlocked = game.save.data.unlockedRoom;
  const screen = el('div', 'screen rooms');

  const header = el('div', 'board-head');
  header.append(
    ransom('ROOMS', 33, 'board-title'),
    el('div', 'tape-label', unlocked === 0 ? '1 room open so far' : `${unlocked + 1} rooms open — pick any`),
  );

  const board = el('div', 'board key-rack');
  const grid = el('div', 'rack-grid');
  for (let i = 0; i <= unlocked; i++) {
    const slot = el('div', i === unlocked ? 'rack-slot latest' : 'rack-slot');
    const pin = el('span', 'pin');
    pin.style.setProperty('--pin', PIN_COLORS[i % PIN_COLORS.length]!);
    const tag = button(String(i + 1), 'key-tag', () => onPick(i));
    tag.setAttribute('aria-label', i === unlocked ? `Room ${i + 1}, your furthest` : `Room ${i + 1}`);
    slot.append(pin, tag);
    if (i === unlocked) slot.append(el('span', 'rack-flag', 'furthest'));
    grid.append(slot);
  }
  board.append(grid);

  screen.append(header, board, button('BACK', 'primary', onBack));
  // Start at the end of the rack: the newest rooms are the ones people usually want.
  requestAnimationFrame(() => {
    board.scrollTop = board.scrollHeight;
  });
  return screen;
}
