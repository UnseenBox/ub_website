import type { Game } from '../core/Game';
import type { Settings } from '../save/SaveManager';
import { button, el } from './dom';

export interface PauseActions {
  resume(): void;
  restart(): void;
  settings(): void;
  home(): void;
}

const CONTROLS: ReadonlyArray<readonly [string, string]> = [
  ['WASD / arrows', 'move'],
  ['mouse', 'aim'],
  ['click', 'grab'],
  ['hold + let go', 'charge and throw'],
  ['right click', 'drop'],
  ['space', 'dodge'],
  ['R', 'restart the room'],
  ['Esc', 'pause'],
];

const TOUCH_CONTROLS: ReadonlyArray<readonly [string, string]> = [
  ['left thumb', 'move'],
  ['tap right side', 'grab what is highlighted'],
  ['hold right side', 'charge, let go to throw'],
  ['drag right thumb', 'aim by hand'],
  ['dodge / drop', 'buttons, bottom right'],
];

/** Pause is a hotel door hanger; the controls are a note someone left next to it. */
export function buildPauseMenu(touch: boolean, actions: PauseActions): HTMLElement {
  const screen = el('div', 'screen pause');

  const hanger = el('div', 'hanger');
  const sign = el('div', 'hanger-sign');
  sign.append(el('span', 'hanger-small', 'please'), el('span', 'hanger-big', 'DO NOT'), el('span', 'hanger-big', 'DISTURB'), el('span', 'hanger-small', '(paused)'));
  const buttons = el('div', 'menu-buttons');
  buttons.append(
    button('RESUME', 'primary', actions.resume),
    button('RESTART ROOM', '', actions.restart),
    button('HOUSE RULES', '', actions.settings),
    button('HOME', '', actions.home),
  );
  hanger.append(el('span', 'hanger-hole'), sign, buttons);

  const note = el('div', 'controls-note');
  note.append(el('div', 'note-title', 'how to fight:'));
  for (const [key, action] of touch ? TOUCH_CONTROLS : CONTROLS) {
    const row = el('div', 'control-row');
    row.append(el('span', 'key', key), el('span', '', action));
    note.append(row);
  }
  screen.append(hanger, note);
  return screen;
}

function toggle(labelText: string, value: boolean, onChange: (value: boolean) => void): HTMLElement {
  const row = el('label', 'rule');
  const input = el('input');
  input.type = 'checkbox';
  input.checked = value;
  input.addEventListener('change', () => onChange(input.checked));
  row.append(input, el('span', 'rule-box'), el('span', 'rule-text', labelText));
  return row;
}

/** Settings are the "house rules": a typed sheet with boxes ticked in pen. */
export function buildSettings(game: Game, onBack: () => void): HTMLElement {
  const screen = el('div', 'screen settings');
  const sheet = el('div', 'sheet rules-sheet');
  const head = el('div', 'sheet-head');
  head.append(el('span', 'sheet-title', 'HOUSE RULES'), el('span', 'sheet-no', 'tick as needed'));
  sheet.append(head);

  const settings = game.save.data.settings;
  const change = (apply: (s: Settings) => void): void => {
    apply(settings);
    game.save.write();
    game.applySettings();
  };

  const volumeRow = el('label', 'rule volume');
  const slider = el('input');
  slider.type = 'range';
  slider.min = '0';
  slider.max = '100';
  slider.value = String(Math.round(settings.volume * 100));
  slider.addEventListener('input', () => change((s) => (s.volume = Number(slider.value) / 100)));
  slider.addEventListener('change', () => game.audio.impact('wood', 0.7, 9));
  volumeRow.append(el('span', 'rule-text', 'volume'), slider);

  sheet.append(
    volumeRow,
    toggle('music', settings.music, (v) => change((s) => (s.music = v))),
    toggle('mute everything', settings.muted, (v) => change((s) => (s.muted = v))),
    toggle('less screen shake', settings.reducedShake, (v) => change((s) => (s.reducedShake = v))),
    toggle('high contrast menus', settings.highContrast, (v) => change((s) => (s.highContrast = v))),
  );

  let armed = false;
  const reset = button('SHRED ALL PROGRESS', 'danger', () => {
    if (!armed) {
      armed = true;
      reset.querySelector('.btn-label')!.textContent = 'SURE? CLICK AGAIN TO SHRED';
      return;
    }
    game.save.clear();
    game.applySettings();
    onBack();
  });

  screen.append(sheet, button('BACK', 'primary', onBack), reset);
  return screen;
}
