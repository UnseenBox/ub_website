/**
 * Advertising abstraction. The game only ever talks to AdManager; which network (if any)
 * is behind it is decided once at startup. No ad SDK is referenced from gameplay code.
 *
 * To plug in a real network, implement AdProvider (see README, "How to add an ad provider")
 * and pass it to the AdManager constructor in main.ts.
 */
export type AdPlacement = 'room_complete' | 'retry_after_failures' | 'second_chance' | 'bonus_challenge';

export interface AdProvider {
  readonly name: string;
  initialize(): Promise<void>;
  isAvailable(kind: 'interstitial' | 'rewarded'): boolean;
  /** Resolves when the ad has closed (or immediately if none was shown). */
  showInterstitial(placement: AdPlacement): Promise<void>;
  /** Resolves true only if the player earned the reward. */
  showRewarded(placement: AdPlacement): Promise<boolean>;
}

export interface AdHooks {
  /** Called before an ad opens: pause the simulation and mute audio. */
  onAdStart(): void;
  onAdEnd(): void;
}

const ROOMS_BETWEEN_INTERSTITIALS = 3;
const MIN_SECONDS_BETWEEN_INTERSTITIALS = 120;
const FAILURES_BEFORE_INTERSTITIAL = 3;

export class AdManager {
  private ready = false;
  private roomsSinceAd = 0;
  private failuresSinceAd = 0;
  private lastInterstitialAt = -Infinity;
  private hooks: AdHooks = { onAdStart() {}, onAdEnd() {} };

  constructor(private readonly provider: AdProvider) {}

  setHooks(hooks: AdHooks): void {
    this.hooks = hooks;
  }

  async initialize(): Promise<void> {
    try {
      await this.provider.initialize();
      this.ready = true;
    } catch (error) {
      console.warn(`[ads] provider "${this.provider.name}" failed to initialize; continuing without ads.`, error);
    }
  }

  isAvailable(kind: 'interstitial' | 'rewarded'): boolean {
    return this.ready && this.provider.isAvailable(kind);
  }

  /** Never called mid-action: only from the results screen between rooms. */
  async onRoomComplete(): Promise<void> {
    this.roomsSinceAd++;
    this.failuresSinceAd = 0;
    if (this.roomsSinceAd >= ROOMS_BETWEEN_INTERSTITIALS) await this.interstitial('room_complete');
  }

  /** Called when the player retries after failing; only repeated failures can trigger an ad. */
  async onRetryAfterFailure(): Promise<void> {
    this.failuresSinceAd++;
    if (this.failuresSinceAd >= FAILURES_BEFORE_INTERSTITIAL) await this.interstitial('retry_after_failures');
  }

  private async interstitial(placement: AdPlacement): Promise<void> {
    const now = performance.now() / 1000;
    if (!this.isAvailable('interstitial') || now - this.lastInterstitialAt < MIN_SECONDS_BETWEEN_INTERSTITIALS) return;
    this.hooks.onAdStart();
    try {
      await this.provider.showInterstitial(placement);
      this.lastInterstitialAt = performance.now() / 1000;
      this.roomsSinceAd = 0;
      this.failuresSinceAd = 0;
    } catch (error) {
      console.warn('[ads] interstitial failed', error);
    } finally {
      this.hooks.onAdEnd();
    }
  }

  async showRewarded(placement: AdPlacement): Promise<boolean> {
    if (!this.isAvailable('rewarded')) return false;
    this.hooks.onAdStart();
    try {
      return await this.provider.showRewarded(placement);
    } catch (error) {
      console.warn('[ads] rewarded ad failed', error);
      return false;
    } finally {
      this.hooks.onAdEnd();
    }
  }
}
