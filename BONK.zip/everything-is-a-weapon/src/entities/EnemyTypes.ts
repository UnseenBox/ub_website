export type EnemyTypeId = 'basic' | 'fast' | 'heavy' | 'helmet' | 'shield' | 'electric';

export interface EnemyType {
  readonly id: EnemyTypeId;
  readonly name: string;
  readonly hp: number;
  readonly speed: number;
  readonly mass: number;
  readonly radius: number;
  /** Seconds between noticing the player and acting on it. */
  readonly reaction: number;
  readonly awareness: number;
  /** Multiplier on damage from thrown/pushed objects. */
  readonly impactFactor: number;
  /** Extra multiplier when the object weighs less than 3. */
  readonly lightObjectFactor: number;
  /** Multiplier on stagger time and knockback. */
  readonly staggerFactor: number;
  readonly turnRate: number;
  readonly helmetHp?: number;
  readonly shield?: boolean;
  readonly shockImmune?: boolean;
  readonly electric?: boolean;
  readonly weave?: boolean;
  readonly color: string;
  readonly shade: string;
  readonly scoreBonus: number;
  /** Base pitch of this intruder's voice, in Hz. */
  readonly voice: number;
  /** Cardboard and paper go up faster than timber. */
  readonly burnFactor: number;
}

/**
 * The Movers: a removal crew of living cardboard boxes. New variants are data — add an entry
 * here and a build in rendering/EnemyArt.ts.
 */
export const ENEMY_TYPES: Readonly<Record<EnemyTypeId, EnemyType>> = {
  basic: {
    id: 'basic', name: 'Box', hp: 60, speed: 96, mass: 45, radius: 16, reaction: 0.55, awareness: 330,
    impactFactor: 1, lightObjectFactor: 1, staggerFactor: 1, turnRate: 9, burnFactor: 1.25,
    color: '#c9a070', shade: '#9c7446', scoreBonus: 0, voice: 172,
  },
  fast: {
    id: 'fast', name: 'Express', hp: 34, speed: 172, mass: 28, radius: 13, reaction: 0.25, awareness: 520,
    impactFactor: 1, lightObjectFactor: 1, staggerFactor: 1.25, turnRate: 12, weave: true, burnFactor: 1.7,
    color: '#f6eed8', shade: '#d8ccac', scoreBonus: 50, voice: 258,
  },
  heavy: {
    id: 'heavy', name: 'Crate', hp: 170, speed: 58, mass: 120, radius: 23, reaction: 0.8, awareness: 380,
    impactFactor: 1, lightObjectFactor: 0.25, staggerFactor: 0.35, turnRate: 5, burnFactor: 1,
    color: '#b07a45', shade: '#7a4f28', scoreBonus: 200, voice: 92,
  },
  helmet: {
    id: 'helmet', name: 'Pan Head', hp: 70, speed: 90, mass: 50, radius: 16, reaction: 0.55, awareness: 340,
    impactFactor: 1, lightObjectFactor: 1, staggerFactor: 0.8, turnRate: 9, helmetHp: 55, burnFactor: 1.25,
    color: '#c9a070', shade: '#9c7446', scoreBonus: 100, voice: 160,
  },
  shield: {
    id: 'shield', name: 'Bailiff', hp: 70, speed: 78, mass: 60, radius: 17, reaction: 0.6, awareness: 380,
    impactFactor: 1, lightObjectFactor: 1, staggerFactor: 0.8, turnRate: 2.4, shield: true, burnFactor: 1.25,
    color: '#b58d60', shade: '#86623c', scoreBonus: 150, voice: 135,
  },
  electric: {
    id: 'electric', name: 'Tangle', hp: 80, speed: 84, mass: 45, radius: 16, reaction: 0.5, awareness: 360,
    impactFactor: 1, lightObjectFactor: 1, staggerFactor: 1, turnRate: 9, shockImmune: true, electric: true, burnFactor: 1.25,
    color: '#c9a070', shade: '#9c7446', scoreBonus: 150, voice: 208,
  },
};
